package com.ecommerce_instrumentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
