package com.ecommerce_instrumentos.dto;

import lombok.Data;

import java.io.IOException;
import java.util.stream.Collectors;

@Data
public class FeatureDto {
    private Long id;
    private String name;
    private byte[] icon;


}
