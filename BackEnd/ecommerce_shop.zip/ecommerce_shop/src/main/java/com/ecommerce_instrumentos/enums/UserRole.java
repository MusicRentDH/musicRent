package com.ecommerce_instrumentos.enums;

public enum UserRole {

    ADMIN,
    CUSTOMER

}
