package com.ecommerce_instrumentos.dto;

import com.ecommerce_instrumentos.entity.Feature;
import com.ecommerce_instrumentos.entity.Product;
import jakarta.persistence.*;
import lombok.Data;

@Data
public class ProductFeatureDto {

    private Long id;

    private Product product;

    private Feature feature;

    public ProductFeatureDto(Product product, Feature feature) {
        this.product = product;
        this.feature = feature;
    }
}
